import Data.Char
import Data.List
import Data.Maybe


index :: Eq a => [[a]] -> Int -> [Int]
index [] n = []
index (x:xs) n 
    | x == [] = [n] ++ index xs (n+1)
    | otherwise = index xs (n+1)
 
indicesOfEmpties :: Eq a => [[a]] -> [Int]
indicesOfEmpties [] = []
indicesOfEmpties ls = index ls 1

applyOnWords :: (String -> String) -> String -> String
applyOnWords f st = unwords(map f (words st))

replaceAll :: Eq a => a -> [a] -> a -> [a]
replaceAll a [] b = []
replaceAll a (x:xs) b
    | a == x = b:replaceAll a xs b
    | otherwise = x:replaceAll a xs b

applyWhile' :: (a -> Bool) -> (a -> a) -> [a] -> Bool -> [a]
applyWhile' f1 f2 [] c = []
applyWhile' f1 f2 (x:xs) c
    | f1 x && c = (f2 x):applyWhile' f1 f2 xs c
    | otherwise = x:applyWhile' f1 f2 xs False

applyWhile :: (a -> Bool) -> (a -> a) -> [a] -> [a]
applyWhile f1 f2 ls = applyWhile' f1 f2 ls True

fixedPointIn :: Eq a => (a -> a) -> a -> Int -> Maybe Int
fixedPointIn f x s
    | s < 0 = Nothing
    | otherwise = aux f x s 0
    where 
        aux f x s count
            | count > s = Nothing
            | f x == x = Just count
            | otherwise = aux f (f x) s (count + 1)

lackOfLetters :: String -> [Char] -> Maybe [Char]
lackOfLetters st ls
    | lackOfLetters' st ls == [] = Nothing
    | otherwise = Just (nub(lackOfLetters' st ls))
    where 
        lackOfLetters' [] ls = []
        lackOfLetters' (x:xs) ls
            | isMember (toLower x) ls = lackOfLetters' xs ls
            | otherwise = toLower x: lackOfLetters' xs ls
                where 
                    isMember :: Char -> [Char] -> Bool
                    isMember c [] = False
                    isMember c (x:xs)
                        | c == x = True
                        |otherwise = isMember c xs

maxVal :: Ord b => [a -> b] -> a -> Int -> Int -> (Int, Int)
maxVal [] _ x y = (x,y)
maxVal (f:[]) n x y = (x,y)
maxVal (f:g:gx) n x y
    | (f n) <= (g n) = maxVal (g:gx) n (x+1) (x+1)
    | otherwise = maxVal (g:gx) n (x+1) y

maxValFun :: Ord b => [a -> b] -> a -> Maybe Int
maxValFun [] _ = Nothing
maxValFun fs x = Just $ snd $ maxVal fs x 1 1
    